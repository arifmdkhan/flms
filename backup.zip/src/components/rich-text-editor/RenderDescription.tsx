'use client'

import TextAlign from "@tiptap/extension-text-align";
import { type JSONContent } from "@tiptap/react";
import { generateHTML } from "@tiptap/html";
import StarterKit from "@tiptap/starter-kit";
import { useMemo } from "react";
import parse from 'html-react-parser'
export function RenderDescription({ json }: { json: JSONContent }) {
    const output = useMemo(() => {
        return generateHTML(json, [StarterKit, TextAlign.configure({
            types: ['heading', 'paragraph'],
        })])
    }, [json])
    return (
        <div className="prose max-w-none dark:prose-invert prose-li:marker:text-primary">
            {parse(output)}
        </div>
    )

}