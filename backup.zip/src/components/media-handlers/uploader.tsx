"use client"
import { useCallback, useEffect, useState } from 'react'
import { FileRejection, useDropzone } from 'react-dropzone'
import { Card, CardContent } from '../ui/card'
import { cn } from '@/lib/utils'
import { RenderEmptyState, RenderErrorState, RenderUploadingState, RenderUploadState } from './render-state'
import { toast } from 'sonner'
import { v4 as uuidv4 } from 'uuid';
import { useConstructUrl } from '@/hooks/use-construct-url'

interface UploaderState {
    id: string | null;
    file: File | null;
    uploading: boolean;
    progress: number;
    key?: string;
    isDeleting: boolean;
    error: boolean;
    objectUrl?: string;
    fileType: 'image' | 'video'

}
interface UploaderProps {
    value?: string;
    onChange?: (value: string) => void;
    fileTypeAccepted: 'image' | 'video'
}
export default function Uploader({ value, onChange, fileTypeAccepted }: UploaderProps) {

    const fileUrl = useConstructUrl(value || '')
    const [fileState, setFileState] = useState<UploaderState>({
        file: null,
        error: false,
        id: null,
        uploading: false,
        progress: 0,
        isDeleting: false,
        fileType: fileTypeAccepted,
        key: value,
        objectUrl: value ? fileUrl : undefined,
    })


    function rejectedFiles(fileRejection: FileRejection[]) {
        if (fileRejection.length) {
            const tooManyFiles = fileRejection.find((rejection) => rejection.errors[0].code === 'too-many-files')
            const fileTooLarge = fileRejection.find((rejection) => rejection.errors[0].code === 'file-too-large')

            if (fileTooLarge) {
                toast.error('File size exceeds limit')
            }

            if (tooManyFiles) {
                toast.error('Too many files selected, maximum selection is 1')
            }
        }
    }

    const uploadFile = useCallback(
        async (file: File) => {
            setFileState((prev) => ({
                ...prev,
                uploading: true,
                progress: 0
            }))
            try {
                //get presigned url
                const presignedResponse = await fetch('/api/s3/upload', {
                    method: "POST",
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        fileName: file.name,
                        contentType: file.type,
                        size: file.size,
                        isImage: fileTypeAccepted === 'image' ? true : false,
                    })
                })

                if (!presignedResponse.ok) {
                    toast.error('Failed to get presigned URL')
                    setFileState((prev) => ({
                        ...prev,
                        uploading: false,
                        error: true
                    }))
                    return;
                }
                const { presignedUrl, key } = await presignedResponse.json();
                await new Promise<void>((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.upload.onprogress = (event) => {
                        if (event.lengthComputable) {
                            const progress = Math.round((event.loaded / event.total) * 100);
                            setFileState((prev) => ({
                                ...prev,
                                progress: progress
                            }))
                        }
                    }
                    xhr.onload = () => {
                        if (xhr.status === 200 || xhr.status === 204) {
                            setFileState((prev) => ({
                                ...prev,
                                progress: 100,
                                uploading: false,
                                key: key
                            }));
                            onChange?.(key);

                            toast.success('File uploaded successfully')
                            resolve();

                        }
                        else {
                            reject(new Error('Upload failed'));
                        }

                    }
                    xhr.onerror = () => {
                        reject(new Error('Upload failed due to a network error'));
                    }
                    xhr.open('PUT', presignedUrl);
                    xhr.setRequestHeader('Content-Type', file.type);
                    xhr.send(file);
                })


            } catch {
                toast.error('something went wrong');
                setFileState((prev) => ({
                    ...prev,
                    progress: 0,
                    uploading: false,
                    error: true
                }))

            }


        },
        [fileTypeAccepted, onChange]
    )



    // eslint-disable-next-line react-hooks/preserve-manual-memoization
    const onDrop = useCallback((acceptedFiles: File[]) => {
        // Do something with the files
        if (acceptedFiles.length > 0) {
            const file = acceptedFiles[0];

            if (fileState.objectUrl && !fileState.objectUrl.startsWith('http')) {
                URL.revokeObjectURL(fileState.objectUrl);
            }

            setFileState({
                file: file,
                uploading: false,
                progress: 0,
                objectUrl: URL.createObjectURL(file),
                error: false,
                id: uuidv4(),
                isDeleting: false,
                fileType: fileTypeAccepted
            })

            uploadFile(file)
        }
    }, [fileState.objectUrl, uploadFile, fileTypeAccepted])

    async function handleRemoveFile() {
        if (fileState.isDeleting || !fileState.objectUrl) return;

        try {
            setFileState((prev) => ({
                ...prev,
                isDeleting: true
            }))
            const response = await fetch('/api/s3/delete', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key: fileState.key })
            })

            if (!response.ok) {
                toast.error('Failed to remove file from storage')
                setFileState((prev) => ({
                    ...prev,
                    isDeleting: true,
                    error: true
                }))
                return;
            }
            if (fileState.objectUrl && !fileState.objectUrl.startsWith('http')) {
                URL.revokeObjectURL(fileState.objectUrl);
            }
            onChange?.("");



            setFileState(() => ({
                file: null,
                uploading: false,
                progress: 0,
                objectUrl: undefined,
                error: false,
                id: null,
                isDeleting: false,
                fileType: fileTypeAccepted,
            }))

            toast.success('File removed successfully')


        } catch {
            toast.error('Failed to remove file')
            setFileState((prev) => ({
                ...prev,
                isDeleting: false,
                error: true
            }))

        }

    }

    function renderUploadContent() {
        if (fileState.uploading) {
            return (<RenderUploadingState progress={fileState.progress} file={fileState.file as File} />)
        }
        if (fileState.error) {
            return <RenderErrorState />
        }


        if (fileState.objectUrl) {

            return (
                <RenderUploadState
                    previewUrl={fileState.objectUrl}
                    handleRemoveFile={handleRemoveFile}
                    isDeleting={fileState.isDeleting}
                    fileType={fileState.fileType}
                />
            )
        }
        return <RenderEmptyState isDragActive={isDragActive} />
    }

    useEffect(() => {
        return () => {
            if (fileState.objectUrl && !fileState.objectUrl.startsWith('http')) {
                URL.revokeObjectURL(fileState.objectUrl);
            }
        }
    }, [fileState.objectUrl])

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: fileTypeAccepted === 'video' ? { "video/*": [] } : { "image/*": [] },
        maxFiles: 1,
        multiple: false,
        maxSize: fileTypeAccepted === 'image' ? 5 * 1024 * 1024 : 3000 * 1024 * 1024,
        onDropRejected: rejectedFiles,
        disabled: fileState.uploading || !!fileState.objectUrl
    })
    return (
        <Card {...getRootProps()} className={cn('relative border-2 border-dashed transition-colors duration-200 ease-in-out w-full h-64',
            isDragActive ? 'border-primary bg-primary/10 border-solid' : 'border-border hover:border-primary'

        )}
        >
            <CardContent className='flex items-center justify-center h-full w-full p-4'>
                <input {...getInputProps()} />
                {/* <RenderEmptyState isDragActive={isDragActive} /> */}
                {/* <RenderErrorState/> */}
                {renderUploadContent()}
            </CardContent>
        </Card>
    )
}
