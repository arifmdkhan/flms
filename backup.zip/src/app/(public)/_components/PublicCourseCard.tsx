import { PublicCourseType } from "@/app/data/course/get-all-courses";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useConstructUrl } from "@/hooks/use-construct-url";
import { School, TimerIcon } from "lucide-react";

import Image from "next/image";
import Link from "next/link";


interface PublicCourseCardProps {
    data: PublicCourseType
}

export function PublicCourseCard({ data }: PublicCourseCardProps) {

    const thumbnailUrl = useConstructUrl(data.fileKey)
    return (
        <Card className="group relative py-0 gap-0">
            <Badge className="absolute top-2 right-2 z-10">{data.level}</Badge>
            <Image width={600} height={400} className="w-full rounded-t-xl aspect-video h-full object-cover" src={thumbnailUrl} alt="Thumbnail image of course" />
            <CardContent>
                <Link className="font-medium text-lg line-clamp-2 hover:underline group-hover:text-primary transition-colors" href={`/courses/${data.slug}`}>
                    {data.title}
                </Link>
                <p className="line-clamp-2 text-sm text-muted-foreground leading-tight mt-2">{data.smallDescription}</p>

                <div className="mt-4 flex items-center gap-x-5">
                    <div className="flex items-center gap-x-2">
                        <TimerIcon className="size-6 p-1 rounded-md text-primary bg-primary/10" />
                        <p className="text-sm text-muted-foreground">{data.duration}h</p>
                    </div>
                    <div className="flex items-center gap-x-2">
                        <School className="size-6 p-1 rounded-md text-primary bg-primary/10" />
                        <p className="text-sm text-muted-foreground">{data.category}</p>
                    </div>
                </div>
                <Link className={buttonVariants({
                    className: 'w-full my-4'
                })} href={`/courses/${data.slug}`}>
                    Road More
                </Link>
            </CardContent>

        </Card>
    )

}



export function PublicCourseCardSkeleton() {
    return (
        <Card className="relative py-0 gap-0 overflow-hidden">
            {/* Badge */}
            <div className="absolute top-2 right-2 z-10">
                <Skeleton className="h-6 w-16 rounded-full" />
            </div>


            {/* Thumbnail */}
            <Skeleton className="w-full aspect-video rounded-t-xl" />


            <CardContent className="mt-4 space-y-4">
                {/* Title */}
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />


                {/* Meta */}
                <div className="flex items-center gap-x-8 mt-4">
                    <div className="flex items-center gap-x-2">
                        <Skeleton className="size-6 rounded-md" />
                        <Skeleton className="h-4 w-10" />
                    </div>
                    <div className="flex items-center gap-x-2">
                        <Skeleton className="size-6 rounded-md" />
                        <Skeleton className="h-4 w-16" />
                    </div>
                </div>


                {/* Button */}
                <Skeleton className="h-10 w-full rounded-md my-4" />
            </CardContent>
        </Card>
    )
}