
import { getAllCourses } from '@/app/data/course/get-all-courses'
import React, { Suspense } from 'react'
import { PublicCourseCard, PublicCourseCardSkeleton } from '../_components/PublicCourseCard'

export default function PublicCourseRoute() {
    return (
        <div className='mt-5'>
            <div className='flex flex-col space-y-2 mb-10 items-center'>
                <h1 className='text-3xl md:text-4xl font-bold tracking-tighter'>Explore Courses</h1>
                <p className='text-muted-foreground'>
                    Discover our wide range of courses
                </p>
            </div>
            <Suspense fallback={<LoadingSkeletonLayout />}>

                <RenderCourses />
            </Suspense>
        </div>
    )
}


async function RenderCourses() {
    const courses = await getAllCourses()

    return (
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mx-5'>
            {courses.map((course) => (
                <PublicCourseCard key={course.id} data={course} />
            ))

            }

        </div>
    )

}


function LoadingSkeletonLayout() {
    return (
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mx-5'>
            {Array.from({ length: 9 }).map((_, index) => (
                <PublicCourseCardSkeleton key={index} />
            ))
            }

        </div>
    )
}