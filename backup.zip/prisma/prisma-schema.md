generator client {
  provider = "prisma-client"
  output   = "../src/generated/prisma"
  engineType      = "client" 
}

datasource db {
  provider = "postgresql"
}

model User {
  id            String    @id
  name          String
  email         String
  emailVerified Boolean   @default(false)
  image         String?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @default(now()) @updatedAt
  sessions      Session[]
  accounts      Account[]
  courses       Course[]

  role       String?
  banned     Boolean?  @default(false)
  banReason  String?
  banExpires DateTime?

  @@unique([email])
  @@map("user")
}

model Session {
  id        String   @id
  expiresAt DateTime
  token     String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  ipAddress String?
  userAgent String?
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)

  impersonatedBy String?

  @@unique([token])
  @@map("session")
}

model Account {
  id                    String    @id
  accountId             String
  providerId            String
  userId                String
  user                  User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  accessToken           String?
  refreshToken          String?
  idToken               String?
  accessTokenExpiresAt  DateTime?
  refreshTokenExpiresAt DateTime?
  scope                 String?
  password              String?
  createdAt             DateTime  @default(now())
  updatedAt             DateTime  @updatedAt

  @@map("account")
}

model Verification {
  id         String   @id
  identifier String
  value      String
  expiresAt  DateTime
  createdAt  DateTime @default(now())
  updatedAt  DateTime @default(now()) @updatedAt

  @@map("verification")
}

model Course {
  id               String       @id @default(uuid())
  title            String
  description      String
  fileKey          String
  price            Int
  duration         Int
  level            CourseLevel  @default(Beginner)
  category         String
  smallDescription String
  slug             String       @unique
  status           CourseStatus @default(Draft)
  createdAt        DateTime     @default(now())
  updatedAt        DateTime     @updatedAt
  user             User         @relation(fields: [userId], references: [id], onDelete: Cascade)
  userId           String
  chapter          Chapter[]
}

enum CourseLevel {
  Beginner
  Intermediate
  Advanced
}

enum CourseStatus {
  Draft
  Published
  Achieved
}

model Chapter {
  id        String   @id @default(uuid())
  title     String
  position  Int
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  course    Course   @relation(fields: [courseId], references: [id], onDelete: Cascade)
  courseId  String
  lessons   Lesson[]
}

model Lesson {
  id           String  @id @default(uuid())
  title        String
  position  Int
  description  String?
  thumbnailKey String?
  videoKey     String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  chapter   Chapter  @relation(fields: [chapterId], references: [id], onDelete: Cascade)
  chapterId String
}
